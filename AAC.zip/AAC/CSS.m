clc
clear all
close all

params;
B = 2000;       % bandwidth of CSS
frame_num = 100;  % frame number
fmin = 18000;
fmax = 20000;
chirp_bit0 = chirp_up(fs, T, B, fmin);      % up chirp denotes bit 0
chirp_bit1 = chirp_down(fs, T, B, fmax);    % down chirp denotes bit 0
%% Generate bin data
data = randi([0 1],1,frame_num);

%% CSS modulation
s = [];
% mapping data to chirp symbols
for i = 1:length(data)
    if data(i) == 0
        s = [s,guard,chirp_bit0];
    else
        s = [s,guard,chirp_bit1];
    end 
end

s = [preamble_tri, s];   % transmitted signal
% audiowrite('transmit.wav', s, fs);
%% channel simulation
r = [zeros(1, randi([0 20])), s, zeros(1, randi([0 20]))]; % random delay of the signal
SNR = 20;
r = awgn(r,SNR,'measured'); % add random noise, r is the received signal

%% CSS demodulation
% received_sig_filename = './receive.wav';
% [sig, fs] = audioread(received_sig_filename);
% r = sig(:,1)';
index = PreambleDetectionTriple(r, preamble, 0, 200, 400,5);
received = r(index+length(preamble_tri): index+length(preamble_tri)+frame_num*fs*(T+T_guard)-1);
r_sliced = zeros(frame_num, round(fs*T));
for i = 1:frame_num
    r_sliced(i,:) = received(1+(i-1)*fs*(T_guard+T)+fs*T_guard:1+(i-1)*fs*(T_guard+T)+fs*(T_guard+T)-1);
end

% decode
decoded = zeros(1,length(data));
for i = 1:frame_num
    corr_0 = xcorr(r_sliced(i,:),chirp_bit0);
    corr_1 = xcorr(r_sliced(i,:),chirp_bit1);
    if max(abs(corr_0)) >= max(abs(corr_1))
        decoded(i) = 0;
    else
        decoded(i) = 1;
    end
end

%% BER
ber = sum(abs(data - decoded))/length(data) * 100;

disp(['Ber = ',num2str(ber),'%'])