function Normalized = PreambleNormalization(corr_abs, W)
% Normalize the cross correlation
% input params: 
%           corr_abs: absolute values of cross correlation result
% output params:
%           Normalized: normalizaed cross correlation result

% W is the # of preceding samples

for j = W+1:length(corr_abs)
    Normalized(j-W) = corr_abs(j)/sum(corr_abs(j-W:j-1));
end

end

