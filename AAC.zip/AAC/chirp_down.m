%% functions area
% generate a chirp signal 
% input params: 
%           fs: sampling rate
%           T: duration of the chirp signal
%           B: bandwidth of the chirp signal
%           fmax: initial frequency of the down chirp signal
% output params:
%           s: descret samples of the chirp signal
function s = chirp_down(fs, T, B, fmax)
    t = 1/fs:1/fs:T;
    v = 2*pi*fmax*t - pi*B/T*t.*t;
    s = cos(v);
end
