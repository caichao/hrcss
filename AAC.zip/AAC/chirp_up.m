%% functions area
% generate a chirp signal 
% input params: 
%           fs: sampling rate
%           T: duration of the chirp signal
%           B: bandwidth of the chirp signal
%           fmin: initial frequency of the up chirp signal
% output params:
%           s: descret samples of the chirp signal
function s = chirp_up(fs, T, B, fmin)
    t = 1/fs:1/fs:T;
    v = 2*pi*fmin*t + pi*B/T*t.*t;
    s = cos(v);
end
