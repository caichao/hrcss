function rmsVals = RMS_filter(data, windowSize)
% RMS filter
% input params: 
%           data: data to be processed
%           windowSize: moving window size
% output params:
%           rmsVals: RMS filtered result

% Preallocate RMS filter array
rmsVals = zeros(1,length(data)-windowSize+1);

% Apply RMS filter
for i = 1:(length(data)-windowSize+1)
    windowData = data(i:i+windowSize-1);
    rmsVals(i) = sqrt(mean(windowData.^2));
end

end

