function index = PreambleDetectionTriple(s, preamble, threshold, W, windowSize, M)
% Preamble detection method with three chirp signals
% input params: 
%       s: received signal frame
%       preamble: ideal preamble signal
%       threshold: hard threshold for determing the exisitence of preamble
%       W: the # of normalization preceding samples
% output params:
%       index: synchronized time stamp

[corr, lag] = xcorr(s, preamble);
corr_abs = abs(corr);

Normalized = PreambleNormalization(corr_abs(end-(length(s)+length(preamble)-1):end), W);

RMS_filtered = RMS_filter(Normalized, windowSize);

idx_mean = round(mean(find(RMS_filtered > max(RMS_filtered)*0.7)));
% idx_mean = round(mean(find(RMS_filtered > threshold)));

% divide the possible frame region into 3 sub regions
slice1 = Normalized(idx_mean-719:idx_mean-240);
slice2 = Normalized(idx_mean-239:idx_mean+240);
slice3 = Normalized(idx_mean+241:idx_mean+720);

% find the maximum M values within each sub region
[~,indice1] = sort(slice1, 'descend');
[~,indice2] = sort(slice2, 'descend');
[~,indice3] = sort(slice3, 'descend');

% find the optimal peaks
scores = zeros(M,4);
for i = 1:M
    minimum = 10000;
    min_2 = 0;
    min_3 = 0;
    for m = 1:M
        for n = 1:M
            temp = abs(indice2(m)-indice1(i)-480) + abs(indice3(n)-indice2-480);
            if temp<minimum
                min_2 = m;
                min_3 = n;
                minimum = temp;
            end
        end
    end
    scores(i,:) = [indice1(i) + indice2(min_2) + indice3(min_3), indice1(i), indice2(min_2), indice3(min_3)];
end

[~,idx] = max(scores(:,1));
index = idx_mean + scores(idx,2) - 720;

index = index + length(corr_abs) - (length(s)+length(preamble)-1) + W - 1;
index = lag(index);
index = index + 1;
end

