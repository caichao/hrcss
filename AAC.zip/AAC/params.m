fs = 48000;             % sampling rate
T = 0.035;              % symbol duration
t = 0:1/fs:T-1/fs;
T_guard = 0.005;        % guard interval duration
T_preamble = 0.04;      % preamble duration
fmin_preamble = 18000;  % initial frequency of preamble
B_preamble = 4000;      % bandwidth of preamble

preamble = chirp_up(fs, T_preamble, B_preamble, fmin_preamble);         % single chirp preamble
preamble = preamble/max(abs(preamble));
preamble_tri = [preamble, zeros(1,0.01*fs),zeros(1,0.01*fs)]+[zeros(1,0.01*fs),preamble,zeros(1,0.01*fs)]+[zeros(1,0.01*fs),zeros(1,0.01*fs),preamble];  % three chirps preamble 
preamble_tri = preamble_tri/max(abs(preamble_tri));
guard = zeros(1,fs*T_guard);   % guard interval