clc
clear all
close all

params;
B = 4000;           % bandwidth of HRCSS
frame_num = 100;    % frame number
subfreq_num = 80;   % number of sub frequency
fmin = 18000;
fmax = 22000; 
delta_f = (fmax-fmin)/subfreq_num;
ChirpUp = zeros(subfreq_num, round(fs*T));   % symbol-chirp mapping table
for i = 1:subfreq_num
    ChirpUp(i,:) = chirp_up(fs, T, delta_f, fmin+(i-1)*delta_f);
end

%% Generate bin data
data = randi([0 1],subfreq_num/2,frame_num);

%% CSS modulation
s = [];
% mapping data to chirp symbols
for m = 1:frame_num
    temp = zeros(1,round(fs*T));
    for n = 1:subfreq_num/2
        if data(n,m) == 0
            temp = temp + ChirpUp((n-1)*2+1,:);
        elseif data(n,m) == 1
            temp = temp + ChirpUp((n-1)*2+2,:);
        end
    end
    temp = temp/max(abs(temp));
    s = [s,guard,temp];
end

s = [preamble_tri, s];   % transmitted signal
% audiowrite('transmit.wav', s, fs);
%% channel simulation
r = [zeros(1, randi([0 20])), s, zeros(1, randi([0 20]))]; % random delay of the signal
SNR = 20;
r = awgn(r,SNR,'measured'); % add random noise, r is the received signal
%% CSS demodulation
% received_sig_filename = './receive.wav';
% [sig, fs] = audioread(received_sig_filename);
% r = sig(:,1)';
index = PreambleDetectionTriple(r, preamble,0, 200, 400,5);
received = r(index+length(preamble_tri): index+length(preamble_tri)+frame_num*fs*(T+T_guard)-1);
r_sliced = zeros(frame_num, round(fs*T));
for i = 1:frame_num
    r_sliced(i,:) = received(1+(i-1)*fs*(T_guard+T)+fs*T_guard:1+(i-1)*fs*(T_guard+T)+fs*(T_guard+T)-1);
end

% decode
decoded = zeros(subfreq_num/2,frame_num);
for m = 1:frame_num
    for n = 1:subfreq_num/2
        corr_0 = xcorr(r_sliced(m,:),ChirpUp((n-1)*2+1,:));
        corr_1 = xcorr(r_sliced(m,:),ChirpUp((n-1)*2+2,:));
        if max(abs(corr_0)) >= max(abs(corr_1))
            decoded(n,m) = 0;
        else
            decoded(n,m) = 1;
        end
    end
end

%% BER
ber = sum(sum(abs(data - decoded)))/numel(data) * 100;

disp(['Ber = ',num2str(ber),'%'])