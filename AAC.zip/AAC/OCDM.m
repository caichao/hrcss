clc
clear all
close all

params;
T = 0.04;       % symbol duration
B = 4000;       % bandwidth OCDM
Nsc = T*B;      % number of sub-carriers
dF = B/Nsc;     % sub-carrier spacing (Hz)
frame_num = 100;
fmin = 18000;
fmax = 22000;
fc = (fmin + fmax)/2; % carrier frequency (Hz)
t= 0 : 1/fs :T - 1/fs;	
c1=cos(2*pi*fc*t);	
c2=-sin(2*pi*fc*t);	

%% Discrete Fresnel Transform matrix
phi = zeros(Nsc,Nsc);
for m = 1:Nsc
    for n = 1:Nsc
        phi(m,n) = 1/sqrt(Nsc)*exp(-1i*pi/4)*exp(1i*pi/Nsc*(m-n)^2);
    end
end

%% Generate data
data = randi([0 1],2,Nsc,frame_num);  % QPSK
qam = zeros(Nsc, frame_num);
for m = 1:Nsc
    for n = 1:frame_num
        if (data(1,m,n)) == 0 && (data(2,m,n) == 0)
            qam(m,n) = 1 + 1i; 
        elseif (data(1,m,n)) == 0 && (data(2,m,n) == 1)
            qam(m,n) = -1 + 1i; 
        elseif (data(1,m,n)) == 1 && (data(2,m,n) == 0)
            qam(m,n) = -1 - 1i; 
        elseif (data(1,m,n)) == 1 && (data(2,m,n) == 1)
            qam(m,n) = 1 - 1i; 
        end
    end
end
%% OCDM modulation
x = phi'*qam;
x_real = real(x);
x_imag = imag(x);

%% Up conversion
Hd2 = dsp.FIRInterpolator(2);   % 2x interpolation filter
[a2, b2] = tf(Hd2);
Hd3 = dsp.FIRInterpolator(3);   % 3x interpolation filter
[a3, b3] = tf(Hd3);
x_real = upsample(x_real, 3);   % 3x interpolation
x_real = filtfilt(a3, b3, x_real); 
x_real = upsample(x_real, 2);   % 2x interpolation
x_real = filtfilt(a2, b2, x_real); 
x_real = upsample(x_real, 2);   % 2x interpolation
x_real = filtfilt(a2, b2, x_real);
x_imag = upsample(x_imag, 3);
x_imag = filtfilt(a3, b3, x_imag);
x_imag = upsample(x_imag, 2);
x_imag = filtfilt(a2, b2, x_imag);
x_imag = upsample(x_imag, 2);
x_imag = filtfilt(a2, b2, x_imag);

s = [];
for i = 1:frame_num
    temp = x_real(:,i)'.*c1 + x_imag(:,i)'.*c2;
    temp = temp/max(abs(temp));
    s = [s,guard,temp];
end
s = [preamble_tri, s];      % transmitted signal
% audiowrite('transmit.wav', s, fs);
%% channel simulation
r = [zeros(1, randi([0 20])), s, zeros(1, randi([0 20]))]; % random delay of the signal
SNR = 20;
r = awgn(r,SNR,'measured'); % add random noise, r is the received signal

% r = s;        
% index = 1;        % tight synchronized case(ideal case)
%% Premable detection
% received_sig_filename = './receive.wav';
% [sig, fs] = audioread(received_sig_filename);
% r = sig(:,1)';
index = PreambleDetectionTriple(r, preamble, 0, 200, 400,5);
received = r(index+length(preamble_tri): index+length(preamble_tri)+frame_num*fs*(T+T_guard)-1);
r_sliced = zeros(round(fs*T),frame_num);
for i = 1:frame_num
    r_sliced(:,i) = received(1+(i-1)*fs*(T_guard+T)+fs*T_guard:1+(i-1)*fs*(T_guard+T)+fs*(T_guard+T)-1)';
end

%% Down conversion
r_real=2*r_sliced'.*c1;
r_imag=2*r_sliced'.*c2;

y_de7=fir1(50,1/6); 
for i = 1:frame_num
    r_real(i,:)=conv(r_real(i,:),y_de7,'same');
    r_imag(i,:)=conv(r_imag(i,:),y_de7,'same');
    y_real(i,:) = downsample(r_real(i,:), 12); 
    y_imag(i,:) = downsample(r_imag(i,:), 12);
end
y = y_real + 1i*y_imag; 
y = y.';

%% OCDM demodulation
y = phi*y;
decoded = zeros(2,Nsc,frame_num);
for m = 1:Nsc
    for n = 1:frame_num
        if (real(y(m,n))>0) && (imag(y(m,n))>0)
            decoded(1,m,n) = 0; 
            decoded(2,m,n) = 0;
        elseif (real(y(m,n))<0) && (imag(y(m,n))>0)
            decoded(1,m,n) = 0; 
            decoded(2,m,n) = 1; 
        elseif (real(y(m,n))<0) && (imag(y(m,n))<0)
            decoded(1,m,n) = 1; 
            decoded(2,m,n) = 0; 
        elseif (real(y(m,n))>0) && (imag(y(m,n))<0)
            decoded(1,m,n) = 1; 
            decoded(2,m,n) = 1; 
        end
    end
end

%% BER
ber = sum(sum(sum(abs(data - decoded))))/numel(data) * 100;

disp(['Ber = ',num2str(ber),'%'])
