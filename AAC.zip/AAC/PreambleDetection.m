function index = PreambleDetection(s, preamble, threshold, W)
% Preamble detection method with single chirp
% input params: 
%       s: received signal frame
%       preamble: ideal preamble signal
%       threshold: hard threshold for determing the exisitence of preamble
%       W: the # of normalization preceding samples
% output params:
%       index: synchronized time stamp

[corr, lag] = xcorr(s, preamble);    % cross correlation
corr_abs = abs(corr);

Normalized = PreambleNormalization(corr_abs(end-(length(s)+length(preamble)-1):end), W);

index = find(Normalized > threshold);
index = index(1);
index = index + length(corr_abs) - (length(s)+length(preamble)-1) + W - 1;
index = lag(index) + 1;

end

