clc
clear all
close all

params;
B = 4000;           % bandwidth of OCSS
frame_num = 100;    % frame number
subfreq_num = 2;    % number of sub frequency, power of 2
fmin = 18000;       % frequency lower bound 
fmax = 22000;       % frequency upper bound 
delta_f = (fmax-fmin)/subfreq_num; 

% construct symbol-chirp mapping table
ChirpUp = zeros(subfreq_num, round(fs*T));
ChirpDown = zeros(subfreq_num, round(fs*T));
for i = 1:subfreq_num
    ChirpUp(i,:) = chirp_up(fs, T, delta_f, fmin+(i-1)*delta_f);
    ChirpDown(i,:) = chirp_down(fs, T, delta_f, fmax-(i-1)*delta_f);
end

%% Generate bin data
data = randi([0 1],2*log2(subfreq_num),frame_num);

%% CSS modulation
s = [];
% mapping data to chirp symbols
for i = 1:length(data)
    temp = zeros(1,round(fs*T));
    if data(1,i) == 0
        temp = temp + ChirpUp(1,:);
    elseif data(1,i) == 1
        temp = temp + ChirpUp(2,:);
    end

    if data(2,i) == 0
        temp = temp + ChirpDown(1,:);
    elseif data(1,i) == 1
        temp = temp + ChirpDown(2,:);
    end
    temp = temp/max(abs(temp));
    s = [s,guard,temp];
end

s = [preamble_tri, s];   % transmitted signal
% audiowrite('transmit.wav', s, fs);
%% channel simulation
r = [zeros(1, randi([0 20])), s, zeros(1, randi([0 20]))]; % random delay of the signal
SNR = 20;
r = awgn(r,SNR,'measured'); % add random noise, r is the received signal

%% CSS demodulation
% received_sig_filename = './receive.wav';
% [sig, fs] = audioread(received_sig_filename);
% r = sig(:,1)';
index = PreambleDetectionTriple(r, preamble, 0, 200, 400,5);
received = r(index+length(preamble_tri): index+length(preamble_tri)+frame_num*fs*(T+T_guard)-1);
r_sliced = zeros(frame_num, round(fs*T));
for i = 1:frame_num
    r_sliced(i,:) = received(1+(i-1)*fs*(T_guard+T)+fs*T_guard:1+(i-1)*fs*(T_guard+T)+fs*(T_guard+T)-1);
end

% decode
decoded = zeros(2*log2(subfreq_num),size(data,2));
for i = 1:frame_num
    corr_up_0 = xcorr(r_sliced(i,:),ChirpUp(1,:));
    corr_up_1 = xcorr(r_sliced(i,:),ChirpUp(2,:));
    corr_down_0 = xcorr(r_sliced(i,:),ChirpDown(1,:));
    corr_down_1 = xcorr(r_sliced(i,:),ChirpDown(2,:));

    if max(abs(corr_up_0)) >= max(abs(corr_up_1))
        decoded(1,i) = 0;
    else
        decoded(1,i) = 1;
    end

    if max(abs(corr_down_0)) >= max(abs(corr_down_1))
        decoded(2,i) = 0;
    else
        decoded(2,i) = 1;
    end
end

%% BER
ber = sum(sum(abs(data - decoded)))/numel(data) * 100;

disp(['Ber = ',num2str(ber),'%'])